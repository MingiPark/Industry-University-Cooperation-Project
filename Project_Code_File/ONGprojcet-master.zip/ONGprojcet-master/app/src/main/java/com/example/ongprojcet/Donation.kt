package com.example.ongprojcet

data class Donation (
    var title : String,
    var center : String,
    var purpose : String,
    var content : String,
    var startDate : String,
    var endDate : String
)